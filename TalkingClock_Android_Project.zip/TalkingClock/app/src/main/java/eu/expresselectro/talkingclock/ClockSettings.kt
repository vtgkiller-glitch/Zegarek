package eu.expresselectro.talkingclock

import android.content.Context

object ClockSettings {
    private const val FILE = "talking_clock"
    fun prefs(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    fun interval(context: Context) = prefs(context).getInt("interval", 10)
    fun scheduled(context: Context) = prefs(context).getBoolean("scheduled", false)
    fun start(context: Context) = prefs(context).getInt("start", 7 * 60)
    fun end(context: Context) = prefs(context).getInt("end", 22 * 60)
    fun language(context: Context) = prefs(context).getString("language", "pl") ?: "pl"
    fun speed(context: Context) = prefs(context).getFloat("speed", 1f)
    fun enabled(context: Context) = prefs(context).getBoolean("enabled", false)
    fun inWindow(minute: Int, from: Int, to: Int): Boolean = when {
        from == to -> true // equal times mean a full 24-hour window
        from < to -> minute >= from && minute < to
        else -> minute >= from || minute < to // crosses midnight
    }
}
