package eu.expresselectro.talkingclock

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var schedule: Switch
    private lateinit var startTime: Button
    private lateinit var endTime: Button
    private lateinit var interval: Spinner
    private lateinit var language: Spinner
    private lateinit var speed: SeekBar
    private val intervals = listOf(5, 10, 15, 20, 30, 60)
    private var from = 7 * 60
    private var to = 22 * 60

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
        val p = ClockSettings.prefs(this)
        from = ClockSettings.start(this)
        to = ClockSettings.end(this)
        val root = ScrollView(this)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(30), dp(24), dp(30))
            setBackgroundColor(Color.rgb(247, 249, 252))
        }
        root.addView(panel)
        fun heading(text: String, size: Float = 17f): TextView = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.rgb(23, 36, 56))
            setPadding(0, dp(16), 0, dp(8))
            panel.addView(this)
        }
        heading("TALKING CLOCK", 28f)
        heading("Głosowe oznajmianie godziny", 15f)
        status = heading("", 18f)
        heading("Interwał oznajmiania")
        interval = Spinner(this)
        interval.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, intervals.map { "Co $it minut" })
        interval.setSelection(intervals.indexOf(ClockSettings.interval(this)).coerceAtLeast(0))
        panel.addView(interval)
        heading("Tryb działania")
        schedule = Switch(this).apply { text = "Tylko w wybranych godzinach"; isChecked = ClockSettings.scheduled(this@MainActivity) }
        panel.addView(schedule)
        startTime = Button(this)
        endTime = Button(this)
        panel.addView(startTime)
        panel.addView(endTime)
        fun timeLabel(minutes: Int) = String.format(Locale.ROOT, "%02d:%02d", minutes / 60, minutes % 60)
        fun updateTimes() {
            startTime.text = "Od: ${timeLabel(from)}"
            endTime.text = "Do: ${timeLabel(to)}"
            startTime.isEnabled = schedule.isChecked
            endTime.isEnabled = schedule.isChecked
        }
        updateTimes()
        schedule.setOnCheckedChangeListener { _, _ -> updateTimes() }
        startTime.setOnClickListener {
            TimePickerDialog(this, { _, h, m -> from = h * 60 + m; updateTimes() }, from / 60, from % 60, true).show()
        }
        endTime.setOnClickListener {
            TimePickerDialog(this, { _, h, m -> to = h * 60 + m; updateTimes() }, to / 60, to % 60, true).show()
        }
        heading("Język komunikatów")
        language = Spinner(this)
        language.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Polski", "English"))
        language.setSelection(if (ClockSettings.language(this) == "en") 1 else 0)
        panel.addView(language)
        heading("Szybkość mowy")
        speed = SeekBar(this).apply { max = 150; progress = ((ClockSettings.speed(this) - 0.5f) * 100).toInt().coerceIn(0, 150) }
        panel.addView(speed)
        heading("Zmiany ustawień zatwierdź przyciskiem Start.", 13f)
        val start = Button(this).apply { text = "START / ZAPISZ USTAWIENIA" }
        panel.addView(start)
        val stop = Button(this).apply { text = "STOP" }
        panel.addView(stop)
        start.setOnClickListener {
            p.edit().putInt("interval", intervals[interval.selectedItemPosition])
                .putBoolean("scheduled", schedule.isChecked)
                .putInt("start", from).putInt("end", to)
                .putString("language", if (language.selectedItemPosition == 1) "en" else "pl")
                .putFloat("speed", 0.5f + speed.progress / 100f)
                .putBoolean("enabled", true).apply()
            // Restart service so TTS language and speed are refreshed.
            stopService(Intent(this, ClockService::class.java))
            try {
                startForegroundService(Intent(this, ClockService::class.java).setAction(ClockService.START))
                refreshStatus()
            } catch (e: Exception) {
                p.edit().putBoolean("enabled", false).apply()
                Toast.makeText(this, "Nie można uruchomić usługi: ${e.message}", Toast.LENGTH_LONG).show()
                refreshStatus()
            }
        }
        stop.setOnClickListener {
            p.edit().putBoolean("enabled", false).apply()
            stopService(Intent(this, ClockService::class.java))
            refreshStatus()
        }
        setContentView(root)
        refreshStatus()
    }
    override fun onResume() { super.onResume(); if (::status.isInitialized) refreshStatus() }
    private fun refreshStatus() {
        status.text = if (ClockSettings.enabled(this)) "● Oznajmianie włączone" else "○ Oznajmianie wyłączone"
        status.setTextColor(if (ClockSettings.enabled(this)) Color.rgb(0, 120, 80) else Color.DKGRAY)
    }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
