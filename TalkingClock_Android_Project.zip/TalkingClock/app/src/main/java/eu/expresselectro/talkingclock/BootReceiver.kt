package eu.expresselectro.talkingclock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED && ClockSettings.enabled(context)) {
            try {
                context.startForegroundService(Intent(context, ClockService::class.java).setAction(ClockService.START))
            } catch (_: Exception) {
                // Some device manufacturers restrict background autostart.
            }
        }
    }
}
