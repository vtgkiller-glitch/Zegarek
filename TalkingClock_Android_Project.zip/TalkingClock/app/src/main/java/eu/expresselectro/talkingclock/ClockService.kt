package eu.expresselectro.talkingclock

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.tts.TextToSpeech
import java.time.LocalDateTime
import java.util.Locale

class ClockService : Service(), TextToSpeech.OnInitListener {
    companion object {
        const val START = "eu.expresselectro.talkingclock.START"
        const val STOP = "eu.expresselectro.talkingclock.STOP"
        const val CHANNEL = "clock_status"
        const val NOTIFICATION_ID = 100
    }
    private val handler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var running = false
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val now = LocalDateTime.now()
            val interval = ClockSettings.interval(this@ClockService)
            val minuteOfDay = now.hour * 60 + now.minute
            val allowed = !ClockSettings.scheduled(this@ClockService) ||
                ClockSettings.inWindow(minuteOfDay, ClockSettings.start(this@ClockService), ClockSettings.end(this@ClockService))
            if (now.minute % interval == 0 && allowed) speak(now)
            planNextMinute()
        }
    }
    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "Talking Clock – praca w tle", NotificationManager.IMPORTANCE_LOW))
        tts = TextToSpeech(this, this)
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val locale = if (ClockSettings.language(this) == "en") Locale.UK else Locale("pl", "PL")
            val result = tts?.setLanguage(locale)
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            tts?.setSpeechRate(ClockSettings.speed(this))
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP || !ClockSettings.enabled(this)) {
            ClockSettings.prefs(this).edit().putBoolean("enabled", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop = PendingIntent.getService(this, 1, Intent(this, ClockService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Talking Clock działa")
            .setContentText("Oznajmianie czasu co ${ClockSettings.interval(this)} min")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Zatrzymaj", stop).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NOTIFICATION_ID, notification)
        running = true
        handler.removeCallbacks(tick)
        planNextMinute()
        return START_STICKY
    }
    private fun planNextMinute() {
        handler.removeCallbacks(tick)
        val now = System.currentTimeMillis()
        val delay = 60_000L - now % 60_000L + 150L
        handler.postDelayed(tick, delay)
    }
    private fun speak(now: LocalDateTime) {
        if (!ttsReady) return
        val phrase = if (ClockSettings.language(this) == "en")
            "The time is ${now.hour} ${now.minute.toString().padStart(2, '0')}"
        else "Jest godzina ${now.hour}, ${now.minute.toString().padStart(2, '0')}"
        tts?.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "clock_${now.hour}_${now.minute}")
    }
    override fun onDestroy() {
        running = false
        handler.removeCallbacks(tick)
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
