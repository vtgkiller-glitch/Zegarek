# Talking Clock (Android)

Polsko-angielska aplikacja oznajmiająca aktualną godzinę przez Android TextToSpeech.

## Funkcje
- Interwały: 5, 10, 15, 20, 30, 60 min (domyślnie 10 min).
- Godziny zgodne z zegarem: 12:00, 12:10, 12:20 itd.
- Tryb całodobowy i harmonogram (także przez północ).
- Polski / angielski, regulacja szybkości mowy.
- Praca przy zablokowanym ekranie poprzez foreground service.
- Opcjonalny autostart po restarcie urządzenia (może być ograniczony przez producenta).

## Jak uzyskać APK przez GitHub Actions
1. Utwórz **nowe prywatne repozytorium** GitHub, np. `TalkingClock`.
2. Wgraj **zawartość** tego katalogu do katalogu głównego repozytorium, razem z ukrytym folderem `.github`.
3. Otwórz zakładkę **Actions** i workflow **Build Android APK**.
4. Kliknij **Run workflow** (lub zrób push do gałęzi `main`).
5. Po zakończeniu pobierz artefakt `TalkingClock-debug-apk` i rozpakuj plik `app-debug.apk`.
6. Przenieś APK na telefon i zainstaluj, zezwalając na instalowanie aplikacji z danego źródła.

APK jest debugowo podpisany przez Android Gradle Plugin; nadaje się do testów i instalacji ręcznej, nie do publikacji w Google Play.

## Lokalna kompilacja
Zainstaluj Android Studio (SDK Platform 35, JDK 17) i otwórz katalog projektu. Wybierz **Build > Build APK(s)**. Możesz też użyć lokalnego Gradle 8.10.2: `gradle :app:assembleDebug`.

## Ważne ograniczenia Androida
- Do działania polskich komunikatów konieczny jest zainstalowany polski głos TTS.
- Usługa pierwszoplanowa wyświetla trwałe powiadomienie; niektóre nakładki producentów mogą mimo to ją zatrzymać. Wyłącz optymalizację baterii dla aplikacji, jeśli występują przerwy.
- Po restarcie telefonu autostart zależy od ograniczeń systemu/producenta.
- Komunikaty zależą od głośności multimediów i ustawień audio urządzenia.
- W obecnym kodzie komunikaty są wyzwalane przez zegar usługi i mogą się opóźnić, jeśli system ograniczy jej wykonywanie. Nie jest to alarm o gwarantowanej dokładności.
- Przy braku języka TTS aplikacja nie odtworzy komunikatu (wymagany odpowiedni pakiet głosowy).

## Struktura
`app/src/main/java/eu/expresselectro/talkingclock/` – aplikacja, usługa i ustawienia.
`.github/workflows/build-apk.yml` – automatyczne budowanie.
